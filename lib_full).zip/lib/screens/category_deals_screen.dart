import 'package:flutter/material.dart';
import 'package:grabmeadeal_final/models/deal.dart';
import 'package:grabmeadeal_final/widgets/deal_card.dart';

class CategoryDealsScreen extends StatelessWidget {
  final String category;
  final List<Deal> deals;
  final Set<String> wishlistIds;
  final void Function(Deal) onWishlistToggle;
  final void Function(Deal) onTap;

  const CategoryDealsScreen({
    Key? key,
    required this.category,
    required this.deals,
    required this.wishlistIds,
    required this.onWishlistToggle,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final filteredDeals = deals.where((deal) => deal.category == category).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(category),
        elevation: 2,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        centerTitle: true,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(8),
        itemCount: filteredDeals.length,
        itemBuilder: (context, index) {
          final deal = filteredDeals[index];
          return DealCard(
            deal: deal,
            isInWishlist: wishlistIds.contains(deal.id),
            onWishlistToggle: onWishlistToggle,
            onTap: () => onTap(deal),
          );
        },
      ),
    );
  }
}
