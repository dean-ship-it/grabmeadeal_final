// lib/screens/wishlist_screen.dart

import 'package:flutter/material.dart';
import 'package:grabmeadeal_final/models/deal.dart';
import 'package:grabmeadeal_final/widgets/wishlist_deal_card.dart';

class WishlistScreen extends StatelessWidget {
  final List<Deal> wishlistDeals;
  final Set<String> wishlistIds;
  final void Function(Deal) onWishlistToggle;

  const WishlistScreen({
    super.key,
    required this.wishlistDeals,
    required this.wishlistIds,
    required this.onWishlistToggle, required void Function(Deal deal) onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Wishlist'),
        elevation: 2,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
        centerTitle: true,
      ),
      body: wishlistDeals.isEmpty
          ? const Center(
              child: Text(
                'No deals saved yet!',
                style: TextStyle(fontSize: 18),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 12.0),
              itemCount: wishlistDeals.length,
              itemBuilder: (ctx, i) {
                final deal = wishlistDeals[i];
                return WishlistDealCard(
                  deal: deal,
                  isInWishlist: wishlistIds.contains(deal.id),
                  onTap: () {
                    Navigator.pushNamed(
                      context,
                      '/deal-detail',
                      arguments: deal,
                    );
                  },
                  onWishlistToggle: () => onWishlistToggle(deal), title: '', imageUrl: '', vendor: '',
                );
              },
            ),
    );
  }
}
