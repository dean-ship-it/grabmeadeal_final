import 'package:flutter/material.dart';
import 'package:grabmeadeal_final/models/deal.dart';
import 'package:grabmeadeal_final/widgets/deal_card.dart';
import 'package:grabmeadeal_final/widgets/search_bar.dart';

class DealsScreen extends StatelessWidget {
  final List<Deal> deals;
  final Set<String> wishlistIds;
  final void Function(Deal) onWishlistToggle;

  const DealsScreen({
    super.key,
    required this.deals,
    required this.wishlistIds,
    required this.onWishlistToggle,
  });

  @override
  Widget build(BuildContext context) {
    final sorted = [...deals]..sort((a,b) => b.date.compareTo(a.date));
    return Scaffold(
      appBar: AppBar(title: const Text('Deals')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: CustomSearchBar(
              results: sorted,
              wishlistIds: wishlistIds,
              onWishlistToggle: onWishlistToggle,
              // removed `onSearch: …`
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: sorted.length,
              itemBuilder: (_, i) {
                final deal = sorted[i];
                return DealCard(
                  deal: deal,
                  isInWishlist: wishlistIds.contains(deal.id),
                  onWishlistToggle: () => onWishlistToggle(deal),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
